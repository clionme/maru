< maru >

	by  John Jeong You
	      clionme@yahoo.com
	      Sep~Nov 2012

	License
	    GPL v3.0


< Controls >

	W A S D 		: Moves

	Q			: Guard
	R 			: Poke ( use it after guard )

	E			: Special Attack

	Mouse L-Click 		: Half Swing
	Mouse R-Click 		: Full Swing

	N			: next stage

	K			: kill all enemies
	L			: kill all units

	Mouse Wheel Up		: zoom in
	Mouse Wheel down	: zoom out


< Tips >

	- Use mouse to aim.
	- Guard can not completely stop the swings
	- Left click on zoomed-out screen to move group (stage 8)
	

< Credits for Sprites >

	http://opengameart.org/content/one-more-lpc-alternate-character
	http://opengameart.org/content/alternate-lpc-character-sprites-george
	http://opengameart.org/content/420-pixel-art-icons-for-medievalfantasy-rpg